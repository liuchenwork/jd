<?php
namespace Admin\Model;
use Think\Model;
class NodeModel extends Model{
    //create()方法需要进行处理的方法
    //自动验证
   protected $_validate = array(
       //验证账户是否已经存在 ， 
       //第一个值为 字段名 ， 
       //第二个值为 处理方式 ， 
       //第三个值为 错误提示信息 ， 
       //第四个值为 处理的是否必须验证 0为存在字段就验证（默认） 1为必须验证 2为不为空就验证
       //第五个值为 处理的规则结合第二个值用
       //第六个值为 处理怎样操作数据库的时候验证 1为新增数据的时候验证 2为修改数据的时候验证 3为两个情况都验证(默认)
        array('name' , 'require' , '标题不能为空!' ),
        array('url' , 'require' , '权限路由不能为空!' ),       
   );
   
   //自动完成对数据进行处理
   protected $_auto = array(
       //第一个值为 字段名
       //第二个值为 处理方式
       //第三个值为 处理怎样操作数据库的时候验证 1为新增数据的时候处理 2为修改数据的时候处理 3为两个情况都处理(默认)      
       array('sort','getint','3','callback'),      
   );
   
   protected function getint($sort){
       return (int) $sort;  
   }
}

