<?php
namespace Admin\Model;
use Think\Model;
class RoleModel extends Model{
    
    //create()方法需要进行处理的方法
   
   //自动完成对数据进行处理
   protected $_auto = array(
       //第一个值为 字段名
       //第二个值为 处理方式
       //第三个值为 处理怎样操作数据库的时候验证 1为新增数据的时候处理 2为修改数据的时候处理 3为两个情况都处理(默认)
       array('node_ids','_autonode','3','callback'),     
   );
   
   protected function _autonode( $node_ids=''){       
       return implode(',', $node_ids);
   }
   
   
}