<?php
namespace Admin\Controller;
class AdminController extends AuthController {
    /**
     * 显示管理员表的数据
     */
    public function index(){
        if(isset($_GET['is_use'])){
            if(!empty($_GET['username'])){
                $map['username'] = array('like',"%$_GET[username]%");
            }
            if($_GET['is_use']!=-1){
                $map['is_use'] = $_GET['is_use'];
            }
            $result = D('Admin')->where($map)->select(); 
                        
        }else{
        //获取管理员表中的所有的数据
        $result = D('Admin')->select();
        }
        
         $this->assign('result' , $result);
        //头部信息
        $this->setPageBtn('管理员列表' , '添加管理员'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加管理员表数据内容
     */
    public function add(){
        
        if(IS_POST){            
            $this->_add();
        }
        //获取所有的角色信息
        $result = D('Role')->select();
        $this->assign('role' , $result);
          //头部信息
        $this->setPageBtn('添加管理员' , '管理员列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加管理员执行操作
     */
    protected function _add(){ 
        
        $obj = D('Admin'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改管理员数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            
            $this->_edit();
        }
        //获取所有的角色信息
        $result = D('Role')->select();
        
        $this->assign('role' , $result);
        //获取修改管理员的数据
        $result = D('Admin')->find( (int) $id);
      
        $this->assign('my' , $result);        
       
          //头部信息
        $this->setPageBtn('修改管理员' , '管理员列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改管理员的执行操作
     */
    public function _edit(){
         $obj = D('Admin'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
        
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Admin')->delete((int) $id))
            $this->success('删除数据成功!');
    }
    
    public function getAjax(){
       $data['id'] = $_POST['id'];
       $data['is_use'] = $_POST['is_use'];
      if(M('Admin')->data($data)->save()){
          echo 1;
      }else{
          echo 0;
      }
    }
              
    
}