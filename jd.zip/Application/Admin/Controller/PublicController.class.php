<?php
namespace Admin\Controller;
use Think\Controller;
class PublicController extends Controller {
    
    public function login(){
        
    if(IS_POST){
        //首先验证码是否正确
        $verify = new \Think\Verify();
        if(!$verify->check( $_POST['chkcode'] ))
            $this->error ('你的验证码有误!');
        //验证账号密码是否正确
        $arr = array('username'=>$_POST['username']);
        
       $result = M('Admin')->where($arr)->find();
       
       if( !$result || $result['password']!=md5($_POST['password']) ){
           $this->error('你的账号或密码错误!');
       }
       //登录成功给session赋值然后跳转,
       //登录成功后给session赋权限
      $r_data = M('Role')->find( (int) $result['role_id']);
      $n_data = M('Node')->where(array('id'=>array('in',$r_data['node_ids'])))->select(array('index'=>'url'));
     
      session('ADMIN',array(
          'id'      =>$result['id'],
          'username'=>$result['username'],
          'nodes'   =>$n_data,
      ));
       $this->redirect('Index/index');
    }
        $this->display();
    }
}