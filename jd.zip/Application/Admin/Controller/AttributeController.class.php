<?php
namespace Admin\Controller;
class AttributeController extends AuthController {
    /**
     * 显示属性表的数据
     */
    public function index($type_id=0){
        //把类型id赋值到模板中
        $this->assign('type_id' , $type_id);
        
        $result = M('Attribute')->where(array('type_id'=>$type_id))->select();
        
        $this->assign('data' , $result); 
          //调用私有的方法，去填充下拉框
       $this->getType();
        //头部信息
        $this->setPageBtn('属性列表' , '添加属性'  , U('add') );
        
        $this->display();
    }
    
    /**
     * 添加属性表数据内容
     */
    public function add(){
        
        if(IS_POST){
            
            $this->_add();
        }
        //调用私有的方法，去填充下拉框
       $this->getType();
          //头部信息
        $this->setPageBtn('添加属性' , '属性列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加属性执行操作
     */
    protected function _add(){ 
        
        $obj = M('Attribute'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改属性数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
       //调用私有的方法，去填充下拉框
       $this->getType();
        //获取修改属性的数据
        $result = D('Attribute')->find( (int) $id);
      
        $this->assign('data' , $result);               
          //头部信息
        $this->setPageBtn('修改属性' , '属性列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改属性的执行操作
     */
    public function _edit(){
         $obj = M('Attribute'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Attribute')->delete((int) $id))
            $this->success('删除数据成功!');
    }
    /**
     * 获取类型的信息填充下拉选框
     */
    public function getType(){
         //获取类型的信息填充下拉选框
        $T_data = M('Type')->select();
        
        $this->assign('typeData' , $T_data);
    }
    
}