<?php
namespace Admin\Controller;
class NodeController extends AuthController {
    /**
     * 显示权限表的数据
     */
    public function index(){
        //调用私有方法获得树形结构
        $this->getpad();
        //头部信息
        $this->setPageBtn('权限列表' , '添加权限'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加权限表数据内容
     */
    public function add(){
        
        if(IS_POST){
            $this->_add();
        }
        
        //调用私有方法获得树形结构
        $this->getpad();
          //头部信息
        $this->setPageBtn('添加权限' , '权限列表'  , U('index') );
        $this->display('info');
        
    }
    
    /**
     * 添加权限执行操作
     */
    protected function _add(){ 
        
        $obj = D('Node'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改权限数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
        
        //获取修改权限的数据
        $result = D('Node')->find( (int) $id);
        
        $this->assign('result' , $result);
         //调用私有方法获得树形结构
        $this->getpad();
        
        $this->display('info');
    }
    
    /**
     * 修改权限的执行操作
     */
    public function _edit(){
         $obj = D('Node'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Node')->delete((int) $id))
            M('Node')->where("pid=$id")->delete();
            $this->success('删除数据成功!');
    }
    
    /**
     * 获取树形结构权限表数据
     */
    private function getpad(){
        $result =  M('Node')->order('sort')->select();
        //采用递归函数把得到数据分类
        $data = get_tree($result , 0);
        
        $this->assign('data' , $data);
    }
        
    
}