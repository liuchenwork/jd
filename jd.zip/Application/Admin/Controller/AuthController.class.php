<?php
namespace Admin\Controller;
use Think\Controller;
class AuthController extends Controller {
    //继承父类加载项后，添加自己的部分
    protected function _initialize(){
        //验证是否存在session , 如过不存在提示后跳转到登录页
        $this->checklogin(); 
        //检查是否有权限访问
        $this->checkAuth();
        //附加模板，存在编辑和删除的权限
        $this->assign('_add' , $this->_auth( CONTROLLER_NAME . '/add') );
        $this->assign('_edit' , $this->_auth( CONTROLLER_NAME . '/edit') );
        $this->assign('_del'  , $this->_auth( CONTROLLER_NAME . '/del') );
        
    }
    
    private function checklogin(){
        
        $info = session('ADMIN');
        
        if(!isset($info) || !isset($info['username'])){   
            
            echo '<script>';
            echo "window.top.location.href='" . U('Public/login') ." '";
            echo '</script>';
            
        }
    }
    
    /**
     *  //显示页面的头部附加添加信息
     * @param type $title 标题信息字符串 
     * @param type $btnName 添加按键
     * @param type $btnLink 添加按键路由
     */
    public function setPageBtn($title, $btnName, $btnLink){
            $this->assign('_page_title', $title);
            $this->assign('_page_btn_name', $btnName);
            $this->assign('_page_btn_link', $btnLink);
    }
    
     private function checkAuth(){
        //获取session中已路径为下表的数组
        $nodes = $_SESSION['ADMIN']['nodes'] ;
        //拼接当前的路由
        $url = CONTROLLER_NAME . '/' . ACTION_NAME;
        //获取公共访问权限的路由
        $p_arr = array(
            //主页显示效果
            'Index/index' ,'Index/menu' , 'Index/main' ,'Index/top' ,
        );
        if(!isset($nodes[ $url ]) && !in_array( $url ,$p_arr )){
            
           $this->error('不允许访问' , U('Index/index'));
        }       
    }
    
    private function _auth($url){
        $nodes = $_SESSION['ADMIN']['nodes'] ;
        if(isset($nodes[ $url ]) ){
            return true;
        }else{
            return false;
        }
    }
}