<?php
namespace Admin\Controller;
class RoleController extends AuthController {
    /**
     * 显示角色表的数据
     */
    public function index(){
        if(!empty($_GET['role_name'])){
            
            $map['name'] = array('like',"%$_GET[role_name]%");
            
            $result = D('Role')->where($map)->select(); 
                        
        }else{
        //获取角色表中的所有的数据
        $result = D('Role')->select();
        }
        //获取权限表的数据
        $n_data = D('Node')->select(array('index'=>'id'));
        //重新把获取的角色的每个权限名称赋值到个个角色中
        foreach ($result as $k => &$v) {
            //利用值传递，把对应权限的id换成对应的权限的名字
            $arr = explode(',', $v['node_ids']);
            
            $v['node_ids'] = array();
            
             foreach($arr as $v1){
                 
                 array_push( $v['node_ids'] , $n_data[$v1][name]);
             }         
        }        
         $this->assign('result' , $result);
        //头部信息
        $this->setPageBtn('角色列表' , '添加角色'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加角色表数据内容
     */
    public function add(){
        
        if(IS_POST){
            
            $this->_add();
        }
        //调用私有的方法，利用循环实现无限级分类
        $this->getpad();
          //头部信息
        $this->setPageBtn('添加角色' , '角色列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加角色执行操作
     */
    protected function _add(){ 
        
        $obj = D('Role'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改角色数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
        
        //获取修改角色的数据
        $result = D('Role')->find( (int) $id);
      
        $this->assign('my' , $result);        
         //调用私有的方法，利用循环实现无限级分类
        $this->getpad();
          //头部信息
        $this->setPageBtn('修改角色' , '角色列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改角色的执行操作
     */
    public function _edit(){
         $obj = D('Role'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Role')->delete((int) $id))
            $this->success('删除数据成功!');
    }
    
    /**
     * 运用循环方法实现无限级分类
     */
    private function getpad(){
         //运用循环方法实现无限级分类
        $result = D('Node')->select(array('index'=>'id'));
        //设置一个空数组,生成一个实现无限分类的数组
        foreach($result as $v){
            
            $data[ $v['pid'] ][] = $v['id']; 
        }
       
        $this->assign('de_data' , $data);
        //把需要id对应的数据赋值到模板中
        $this->assign('n_data' , $result);
    }
              
    
}