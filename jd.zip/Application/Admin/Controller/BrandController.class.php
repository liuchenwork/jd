<?php
namespace Admin\Controller;
class BrandController extends AuthController {
    /**
     * 显示品牌表的数据
     */
    public function index(){
        if(!empty($_GET['brand_name'])){
            
            $map['brand_name'] = array('like',"%$_GET[brand_name]%");
            
            $result = M('Brand')->where($map)->select(); 
                        
        }else{
        //获取角色表中的所有的数据
            $result = M('Brand')->select();
        }       
        
        $this->assign('data' , $result);        
        //头部信息
        $this->setPageBtn('品牌列表' , '添加品牌'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加品牌表数据内容
     */
    public function add(){
        
        if(IS_POST){
          
            $this->_add();
        }
     
          //头部信息
        $this->setPageBtn('添加品牌' , '品牌列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加品牌执行操作
     */
    protected function _add(){ 
        
        $obj = M('Brand'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改品牌数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
        
        //获取修改品牌的数据
        $result = M('Brand')->find( (int) $id);
      
        $this->assign('data' , $result);               
          //头部信息
        $this->setPageBtn('修改品牌' , '品牌列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改品牌的执行操作
     */
    public function _edit(){
         $obj = M('Brand'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        //查找图片的路径
         $result = M('Brand')->find( (int) $id);
         
         unlink('.'.C('TMPL_PARSE_STRING.__LOGO_UPLOADS__').'/'.substr($result['file'],1)); 
        if(M('Brand')->delete((int) $id))
            $this->success('删除数据成功!');
    }
                 
     /**
     * 文件上传的方法
     */
    public function mulUpload(){       
       echo  upload();              
    }
    
    /**
     * 文件删除的方法 , 插件中自带的删除功能，每次只会删除一张图片的
     * /Public/Upload/Doc   2017-01-13/5878c3467d7f5.jpg
     */
    public function delFile(){       
        $path = $_POST[ '_rootpath' ];
        $file = $_POST[ 'raw' ];
        
        unlink( '.' . $path . '/' . $file);        
    }
    
}