<?php
namespace Admin\Controller;
class IndexController extends AuthController {
    
    public function index(){
        $this->display();
    }
    
    public function top(){
        $this->display();
    }
    
    public function menu(){
        //寻找显示的权限列表,实现无限级分类       
        $result = session('ADMIN.nodes');
        //获取session中的权限
        foreach($result as $v){
            $n_data[$v['pid']][] = $v['id'];
        }
        //因为session中的权限是已url做下标的，这里需要的是id做下标的，重新从数据库中获取一个数组
        $result1 = M('Node')->where('is_show=1')->select(array('index'=>'id'));
        $this->assign('result' , $result1);
        $this->assign('n_data' , $n_data);
        $this->display();
    }
    
    public function main(){
        $this->display();
    }
    
}