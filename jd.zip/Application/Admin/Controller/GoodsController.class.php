<?php
namespace Admin\Controller;
class GoodsController extends AuthController {
    /**
     * 显示商品表的数据
     */
    public function index(){
        
        //头部信息
        $this->setPageBtn('商品列表' , '添加商品'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加商品表数据内容
     */
    public function add(){
        
        if(IS_POST){
            
            $this->_add();
        }
        //商品分类下拉列表获取
         $result = M('Category')->select();
        //形成树形结构
        $result  = get_tree($result , 0 ,0 , $id );
        
        $this->assign('catData' , $result); 
        
        //品牌下拉列表获取
         $brandData = M('Brand')->select();
         
         $this->assign('brandData' , $brandData);
         
         //类型分类下拉列表获取
        $t_result = M('Type')->select();
        
        $this->assign('typeData' , $t_result); 
        
        //属性下拉列表获取
        
          //头部信息
        $this->setPageBtn('添加商品' , '商品列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加商品执行操作
     */
    protected function _add(){ 
        
        $obj = D('Goods'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改商品数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
        
        //获取修改商品的数据
        $result = D('Goods')->find( (int) $id);
      
        $this->assign('my' , $result);        
         //调用私有的方法，利用循环实现无限级分类
        $this->getpad();
          //头部信息
        $this->setPageBtn('修改商品' , '商品列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改商品的执行操作
     */
    public function _edit(){
         $obj = D('Goods'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Goods')->delete((int) $id))
            $this->success('删除数据成功!');
    }
    
    /**
     * 运用循环方法实现无限级分类
     */
    private function getpad(){
         //运用循环方法实现无限级分类
        $result = D('Node')->select(array('index'=>'id'));
        //设置一个空数组,生成一个实现无限分类的数组
        foreach($result as $v){
            
            $data[ $v['pid'] ][] = $v['id']; 
        }
       
        $this->assign('de_data' , $data);
        //把需要id对应的数据赋值到模板中
        $this->assign('n_data' , $result);
    }
              
    public function ajaxGetAttr($type_id=0){
        
         $result = M('Attribute')->where(array('type_id'=>$type_id))->select();
        
         echo json_encode($result);
    }
}