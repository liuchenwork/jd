<?php
namespace Admin\Controller;
class TypeController extends AuthController {
    /**
     * 显示类型表的数据
     */
    public function index(){
        
        $result = M('Type')->select();
        
        $this->assign('data' , $result);        
        //头部信息
        $this->setPageBtn('类型列表' , '添加类型'  , U('add') );
        $this->display();
    }
    
    /**
     * 添加类型表数据内容
     */
    public function add(){
        
        if(IS_POST){
            
            $this->_add();
        }
     
          //头部信息
        $this->setPageBtn('添加类型' , '类型列表'  , U('index') );
        
        $this->display('info');
        
    }
    
    /**
     * 添加类型执行操作
     */
    protected function _add(){ 
        
        $obj = M('Type'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->add()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 修改类型数据内容
     */
    public function edit($id=0){
        
        if(IS_POST){
            $this->_edit();
        }
        
        //获取修改类型的数据
        $result = D('Type')->find( (int) $id);
      
        $this->assign('data' , $result);               
          //头部信息
        $this->setPageBtn('修改类型' , '类型列表'  , U('index') );
        
        $this->display('info');
    }
    
    /**
     * 修改类型的执行操作
     */
    public function _edit(){
         $obj = M('Type'); 
        
        if(!$obj->create())
            $this->error('创建数据失败!'.$obj->getError());  
       
        if($obj->save()===false )
            $this->error('插入数据失败'.$obj->getDbError ());          
        else
            $this->success('插入数据成功');
        exit;
    }
    
    /**
     * 删除数据
     */
    public function del($id=0){
        if(M('Type')->delete((int) $id))
            $this->success('删除数据成功!');
    }
                 
    
}