<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <style type="text/css" >
    	form{
			margin:200px auto;
			width:500px;
		}
    </style>
    <body>    	
        <form action="data.php" method="post">
        <table>
            <tr>
                <td>手机号码：</td>
                <td><input type="text" name="phone" id="phone" ><input type="button" id="btn" value="点击获取验证码"/></td>
            </tr>
            <tr>
                <td>输入验证码:</td>
                <td><input type="text"/></td>            
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="登录"/></td>
            </tr>
        </table>
        </form>
    </body>
</html>
<script type="text/javascript" src="/Public/Vendor/jquery/jquery-1.6.2.min.js"></script>
<script>
	var flage= false;
	$('#btn').click(function(){
			
		//获取手机号码
		var phone = $('#phone').val();
		//判断手机号是否合法	
		var reg = /^0?1[34568]\d{9}$/;
		//如果手机号码为空，或者手机号码不合法
		if(!reg.test(phone)){
			alert('你输入的手机号码不正确!请核对后再输入!');
			return false;
		}
		//为防止手机获取短信的行为被多次触发，需要加判断条件
		if(flage){
			alert('验证短信!已发送!请注意查收!失效期内不能重复的获取!');
			return false;
		}
		//连接短信ajax
		$.get("/index.php/Api/Index/getRL/phone/"+phone,function(data){
			var obj = $.parseJSON(data);
			//如果返回的sign的0，表示短信发送成功!
			if(obj.sign==0){
				flage = true ;
				//60秒之后重新获取 
				var time=60 ; 
				var _time = setInterval(function(){
					if(time<1){
						$('#btn').val('点击获取验证码').attr('disabled',false);
						//清除记时器
						clearInterval(_time);
					}else{
						$('#btn').val((time--)+'S秒后重新获取验证码!').attr('disabled',true);						
					}
				},1000);
			}else{
				alert(obj.msg);
				return false;				
			}
		});
	})
	
</script>