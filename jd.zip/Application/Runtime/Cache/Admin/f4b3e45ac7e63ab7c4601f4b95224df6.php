<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>管理中心</title>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/Public/Admin/Styles/general.css" rel="stylesheet" type="text/css" />
<link href="/Public/Admin/Styles/main.css" rel="stylesheet" type="text/css" />
<!--<link href="/Public/datepicker/jquery-ui-1.9.2.custom.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="/Public/datepicker/jquery-1.7.2.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/jquery-ui-1.9.2.custom.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/datepicker_zh-cn.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>-->

</head>
<body>
<h1>
    <?php if($_add): ?><span class="action-span"><a href="<?php echo ($_page_btn_link); ?>"><?php echo ($_page_btn_name); ?></a></span><?php endif; ?>
    <span class="action-span1"><a href="#">管理中心</a></span>
    <span id="search_id" class="action-span1"> - <?php echo ($_page_title); ?> </span>
    <div style="clear:both"></div>
</h1>

<!-- 页面中的内容 -->

<div class="main-div">
    <form name="main_form" method="POST" action="/index.php/Admin/Category/add.html" enctype="multipart/form-data" >
    	<input type="hidden" name="id" value="<?php echo ($my['id']); ?>" />
        <table cellspacing="1" cellpadding="3" width="100%">
			<tr>
				<td class="label">上级类别：</td>
				<td>
					<select name="pid">
						<option value="0">顶级类别</option>
                        <?php if(is_array($data)): foreach($data as $k=>$v): ?><option  value="<?php echo ($v['id']); ?>"><?php echo str_repeat('-', 8*$v['leaf']).$v['cat_name'];?></option><?php endforeach; endif; ?>					
                    </select>
				</td>
			</tr>
            <tr>
                <td class="label">分类名称：</td>
                <td>
                    <input  type="text" name="cat_name" value="<?php echo ($my['cat_name']); ?>" />
                </td>
            </tr>
            <tr>
                <td class="label">筛选属性：</td>
                <td>
	                <ul>
                    	<?php if($searchAttrData): if(is_array($searchAttrData)): foreach($searchAttrData as $k1=>$v1): ?><li>
                                <a href="javascript:void(0);" onclick="addNew(this);"><?php echo ($k1?'[-]':'[+]'); ?></a>
                                <select name="type_id[]">
                                    <option value="">选择类型</option>
                                    <?php if(is_array($typeData)): foreach($typeData as $k=>$v): ?><option  value="<?php echo ($v["id"]); ?>" <?php echo ($v1['type_id']==$v['id']?'selected':''); ?>><?php echo ($v["type_name"]); ?></option><?php endforeach; endif; ?>
                                </select>
                                <select attr_id="<?php echo ($v1["id"]); ?>" name="search_attr_id[]">
                                    <option value="">选择属性</option>
                                </select>
                            </li><?php endforeach; endif; ?>                        	
                        <?php else: ?>
                            <li>
                                <a href="javascript:void(0);" onclick="addNew(this);">[+]</a>
                                <select name="type_id[]">
                               		<option value="">选择类型</option>
                                    <?php if(is_array($typeData)): foreach($typeData as $k=>$v): ?><option  value="<?php echo ($v["id"]); ?>" ><?php echo ($v["type_name"]); ?></option><?php endforeach; endif; ?>
                                </select>
                                
                                <select name="search_attr_id[]">
                                    <option value="">选择属性</option>
                                </select>
                            </li><?php endif; ?>	                
	                </ul>
                </td>
            </tr>
            <tr>
                <td colspan="99" align="center">
                    <input type="submit" class="button" value=" 确定 " />
                    <input type="reset" class="button" value=" 重置 " />
                </td>
            </tr>
        </table>
    </form>
</div>
<script>
window.onload=function(){
	
$("select[name='type_id[]']").change(function(){
	// 把下拉框给另一个变量，然后在后面的AJAX的大括号可以用_this这个变量代码这个拉框框，因为ajax中的$(this)已经不再代码下拉框了，而是代码那个AJAX
	var _this = $(this);
	// 获取选择的类型的ID
	var typeId = $(this).val();
	var opt = "<option value=''>选择属性</option>";
	// 如果选择了一个类型就执行AJAX取出个类型下的属性
	if(typeId != "")
	{
		//通过ajax获取下拉选框的属性的内容
		$.get("/index.php/Admin/Category/ajaxGetAttr/type_id/"+typeId,function(data){
			//php中传递过来的是json，转换成对象
			var result = $.parseJSON(data);
			//获取默认的属性的id
			var attrId = _this.next('select').attr('attr_id');
			//遍历数组，判断如果是默认的，处于选中状态
			$.each(result , function(k,v){
				if(v.id == attrId)
						var sel = 'selected="selected"';
					else
						var sel = '';
				opt += "<option value='" + v.id +  "' " + sel + ">" + v.attr_name + "</option>";
			})
			_this.next("select").html(opt);
		})
		
	}
	else
		_this.next("select").html(opt);
});

// 直接触AJAX事件取出属性
$("select[name='type_id[]']").trigger("change");
}

function addNew(a)
{
	var li = $(a).parent();
	if($(a).html() == "[+]")
	{
		var newli = li.clone(true);  // 深度克隆，把标签上的事件也克隆
		newli.find("a").html("[-]");
		li.after(newli);
	}
	else
		li.remove();
}
</script>

<div id="footer">liuchen</div>
</body>
</html>

<script type="text/javascript" charset="utf-8" src="/Public/Admin/Js/tron.js"></script>
<script type="text/javascript" src="/Public/Vendor/jquery/jquery-1.6.2.min.js"></script>