<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>管理中心</title>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/Public/Admin/Styles/general.css" rel="stylesheet" type="text/css" />
<link href="/Public/Admin/Styles/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/Public/Vendor/jquery/jquery-1.6.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/Vendor/jquery/lamUploader/lamUploader.css" />
<script type="text/javascript" src="/Public/Vendor/validator.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/My97DatePicker/WdatePicker.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/ueditor/ueditor.config.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/ueditor/ueditor.all.min.js"></script>
<script src="/Public/Vendor/jquery/lamUploader/webuploader.min.js"></script>
<script src="/Public/Vendor/jquery/lamUploader/lamUploader.min.js" id="lamUploader"></script>
<!--<link href="/Public/datepicker/jquery-ui-1.9.2.custom.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="/Public/datepicker/jquery-1.7.2.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/jquery-ui-1.9.2.custom.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/datepicker_zh-cn.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>-->


</head>
<body>
<h1>
    <?php if($_add): ?><span class="action-span"><a href="<?php echo ($_page_btn_link); ?>"><?php echo ($_page_btn_name); ?></a></span><?php endif; ?>
    <span class="action-span1"><a href="#">管理中心</a></span>
    <span id="search_id" class="action-span1"> - <?php echo ($_page_title); ?> </span>
    <div style="clear:both"></div>
</h1>

<!-- 页面中的内容 -->

<div class="main-div">
    <form name="main_form" method="POST" action="/index.php/Admin/Admin/edit/id/1.html" enctype="multipart/form-data" onSubmit="return Validator.Validate(this,3)" >
        <table cellspacing="1" cellpadding="3" width="100%">
        	<tr>
                <td class="label">所在角色：</td>
                <td>                	 
                    <select name="role_id" style="width:261px;">         		
                        <?php if(is_array($role)): foreach($role as $key=>$vo): ?><option value="<?php echo ($vo["id"]); ?>" >
                                <?php echo ($vo["name"]); ?>
                            </option><?php endforeach; endif; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td class="label">账号：</td>
                <td>
                    <input type="text" name="username" dataType='Require' value="<?php echo ($my['username']); ?>"  <?php if( $my ): ?>disabled="disabled"<?php endif; ?> />
                </td>
            </tr>
            <tr>
                <td class="label">密码：</td>
                <td>
                    <input name="password" <?php if( !$my ): ?>dataType="SafeString"<?php endif; ?>   msg="密码不符合安全规则" type="password"><?php if( $my ): ?>留空代表不修改密码<?php endif; ?>
                </td>
            </tr>
            <tr>
                <td class="label">确认密码：</td>
                <td>
                    <input name="repeat" dataType="Repeat" to="password" msg="两次输入的密码不一致" type="password">
                </td>
            </tr>
            <tr>
                <td class="label">真实姓名：</td>
                <td>
                    <input type="text" name="truename" dataType='Chinese' msg="真实姓名只允许中文" value="<?php echo ($my['truename']); ?>"/>
                </td>
            </tr>
             <tr>
                <td class="label">电话号码：</td>
                <td>
                  <input type="text" value="<?php echo ($my['mobile']); ?>" name="mobile" dataType='Mobile' />
                </td>
            </tr>
             <tr>
                <td class="label">邮 箱：</td>
                <td>
                   <input type="text" value="<?php echo ($my['email']); ?>" name="email" dataType='Email' />
                </td>
            </tr>
            <tr>
                <td class="label">是否启用</td>
                <td>
                	<input type="radio" name="is_use" value="1" checked="checked" />启用 
                	<input type="radio" name="is_use" value="0"  />禁用 
                </td>
            </tr>
            <input type="hidden" name="id" value="<?php echo ($_GET['id']); ?>" />
            <tr>
                <td colspan="99" align="center">
                    <input type="submit" class="button" value=" 确定 " />
                    <input type="reset" class="button" value=" 重置 " />
                </td>
            </tr>
        </table>        
    </form>
</div>
<script type="text/javascript" src="/Public/Vendor/validator.js"></script>
<script>
</script>

<div id="footer">liuchen</div>
</body>
</html>

<script type="text/javascript" charset="utf-8" src="/Public/Admin/Js/tron.js"></script>