<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>管理中心</title>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/Public/Admin/Styles/general.css" rel="stylesheet" type="text/css" />
<link href="/Public/Admin/Styles/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/Public/Vendor/jquery/jquery-1.6.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/Vendor/jquery/lamUploader/lamUploader.css" />
<script type="text/javascript" src="/Public/Vendor/validator.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/My97DatePicker/WdatePicker.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/ueditor/ueditor.config.js "></script><script type="text/javascript" src="/Public/Vendor/jquery/ueditor/ueditor.all.min.js"></script>
<script src="/Public/Vendor/jquery/lamUploader/webuploader.min.js"></script>
<script src="/Public/Vendor/jquery/lamUploader/lamUploader.min.js" id="lamUploader"></script>
<!--<link href="/Public/datepicker/jquery-ui-1.9.2.custom.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" language="javascript" src="/Public/datepicker/jquery-1.7.2.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/jquery-ui-1.9.2.custom.min.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/datepicker/datepicker_zh-cn.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/Public/ueditor/lang/zh-cn/zh-cn.js"></script>-->


</head>
<body>
<h1>
    <?php if($_add): ?><span class="action-span"><a href="<?php echo ($_page_btn_link); ?>"><?php echo ($_page_btn_name); ?></a></span><?php endif; ?>
    <span class="action-span1"><a href="#">管理中心</a></span>
    <span id="search_id" class="action-span1"> - <?php echo ($_page_title); ?> </span>
    <div style="clear:both"></div>
</h1>

<!-- 页面中的内容 -->

<style>
.tab{background:#99F; border-spacing:1px; border-collapse:separate;}
.tab th{width:150px; font-weight:bold;}
.tab th, .tab td{background:#FFF;}
.tab td{width:800px;}
.tab td > label{display:block; margin-top:20px;}
.tab td label{display:inline-block; width:25%; line-height:1.5;}
</style>
<div class="title"><h2><?php echo ($text); ?></h2></div>
<form action="?" method="post" class="main" onSubmit="return Validator.Validate(this,3)" >
    <p class="short-input ue-clear">
        <label>角色名称：</label>
        <input type="text" name="name" dataType='Require' value="<?php echo ($my['name']); ?>"   />
    </p>

    <p class="short-input ue-clear">
        <label>角色介绍：</label>
        <input type="text" name="remark" dataType='Require'  value="<?php echo ($my['remark']); ?>"/>
    </p>
    <p class="short-input ue-clear">
        <label>选择权限：</label>
        <label><input type="checkbox" onclick="checkAll(this)"/></label>        
    </p>
    <table class='tab'>
    <?php if(is_array($de_data[0])): foreach($de_data[0] as $key=>$v1): ?><tr>
        <th>
        	<label>
            	<input type="checkbox" name="node_ids[]" value="<?php echo ($v1); ?>" id="ids<?php echo ($v1); ?>" onclick="checkAll(this)" /><?php echo ($n_data[$v1]['name']); ?>
        	</label>
        </th>
        <td>
        <?php if(is_array($de_data[$v1])): foreach($de_data[$v1] as $k2=>$v2): ?><div>         
                <label>
                    <input type="checkbox" name="node_ids[]"  value="<?php echo ($v2); ?>" id="ids<?php echo ($v2); ?>" onclick="checkpart(<?php echo ($v1); ?> , this),checkAll(this)"/><?php echo ($n_data[$v2]['name']); ?> 
                </label>
            </div> 
            <div>
            <?php if(is_array($de_data[$v2])): foreach($de_data[$v2] as $k3=>$v3): ?><label>
            	<input type="checkbox" name="node_ids[]"  value="<?php echo ($v3); ?>"  onclick="checkpart(<?php echo ($v2); ?> , this),checkpart(<?php echo ($v1); ?> , this)"/><?php echo ($n_data[$v3]['name']); ?> 
            </label><?php endforeach; endif; ?>
            </div>  
            <hr/><?php endforeach; endif; ?>
        </td>       
   </tr><?php endforeach; endif; ?> 
	</table>  
    <input type="hidden" name="id" value="<?php echo ($_GET['id']); ?>" />
    
<div class="btn ue-clear">
    <button type="submit" id="confirm" class="confirm">确定</button>
    <button type="button" id="reset1" class="clear" onclick=" set_clear(this.form) ">清空内容</button>
</div>
</form>
<script src="/Public/Vendor/validator.js"></script>
<script>		
	//选择项
	//选择所有的子项
	function checkAll(obj){			
		$(obj).parent().parent().next().find('input').prop('checked',obj.checked);
	}
	//选择一个子项之后选择其父项
	function checkpart( id , obj ){		
		$('#ids'+id).prop('checked' , true);
	}
	window.onload=function(){
		$("input[name='node_ids[]']").val( [ <?php echo ($my['node_ids']); ?> ] );
	}
</script>

<div id="footer">liuchen</div>
</body>
</html>

<script type="text/javascript" charset="utf-8" src="/Public/Admin/Js/tron.js"></script>