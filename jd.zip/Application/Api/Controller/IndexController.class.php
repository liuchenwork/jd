<?php
namespace Api\Controller;
use Think\Controller;
class IndexController extends Controller {
    
    public function test1(){
       echo  getRequest("https://www.juhe.cn");
    }
    
    public function test2(){
        //需要调用的webService接口
        $wsl = "http://www.webxml.com.cn/WebServices/MobileCodeWS.asmx?wsdl";
        //实例话soapClient         
        $cli = new \SoapClient($wsl);
        //调用号码查询的接口
        //在这里直接调用的方法的名字，并且以一维数组形式传递参数
        $str = $cli->getMobileCodeInfo(array(
                    'mobileCode'=> '15101012345',
                    'userID'    => '',
                ));
        print_r($str);
    }
    
    // __soapCall 方法用接口,此时是以二位数组形式入参:
    public function test3(){
         //需要调用的webService接口
        $wsl = "http://www.webxml.com.cn/WebServices/MobileCodeWS.asmx?wsdl";
        //实例话soapClient
        $cli = new \SoapClient($wsl);
        //利用php的内置函数来调用接口
        $str = $cli->__soapCall('getMobileCodeInfo', array(array(
                        'mobileCode'=>'15101012345',
                        'userID'    =>''
                    )));
        print_r($str);
    }
    
    public function test4(){
        $phone = '15101012345 ';
        $url = "http://cx.shouji.360.cn/phonearea.php?number=".$phone;
        //调用我们自定义的get请求，获取手机号码
        $str = getRequest($url);
        //将请求到的结果的json字符串转换为php数组
        $arr = json_decode($str,true);
       
        //将查询到的数据，进行整合处理
        if($arr['code']==0){
            echo '手机号码为：'.$phone.'<br/>';
            echo '省份为：'.$arr['data']['province'].'<br/>';
            echo '城市为:'.$arr['data']['city'].'<br/>';
            echo '运营商:'.$arr['data']['sp'].'<br/>';
        }
        
    }
    
    //容联云通信的短信验证接口的应用
    public function duanxin(){
        $this->display( 'duanxin' );
    }
    
    public function getRL($phone){
        $phone = isset($phone)?htmlspecialchars($phone):'';
        
        if($phone==''){
                $this->get_data(3,'illegal params','请输入正确的手机号码!');
                return false;
        }
        
        
         //满足条件调用
     	$key_60s = 'key_60s'.$phone;
     	$key_1d = 'key_1d'.$phone;
        if(!$this->getStatusIn3600($key_60s) || !$this->getStatusIn86400($key_1d) ){
            $this->get_data(4,'Dont again oneday','60s内不能重发一天之内只能验证3次!');
        }
        //随机获取随机数验证码
        $num = rand(10000,99999);
        
        //获取号码之后连接容联云通信
        $result = sendTemplateSMS($phone,array($num,'5'),"1");//手机号码，替换内容数组，模板ID
        
        echo json_encode($result);
    }
    
    /*
    **设置一个数组用来拼接回复的json格式的信息
     */
    private function get_data($sign , $code , $msg){
            $data = array(
                    'sign' 	=> $sign,
                    'code'	=> $code,
                    'msg'	=> $msg,
            );
            echo json_encode($data);die();
    }
    

    //写入数据,1天之内只能发送3条信息
    private function getStatusIn86400($key_1d,$num=3){
            $mem = new \Memcache();
            $mem->connect('127.0.0.1',11211);
            //先获取对应的key值的发送次数	
            $times = (int)$mem->get($key_1d);
            if($times<$num){
                    $left_time = strtotime(date('Y-m-d 23:59:59'))-time();	//当天剩余的时间
                    $mem->set($key_1d,++$times,0,$left_time);
                    return true;
            }else{
                    return false;
            }							
    }
    //增加60秒之内不能发送短信的限制
    private function getStatusIn3600($key_60s,$time=60){
            $mem = new \Memcache();
            $mem->connect('127.0.0.1',11211);
            $times = (int)$mem->get($key_60s);
            if($times){
                    //存在值的话，说明60秒内有发送短信
                    return false;
            }else{
                    $mem->set($key_60s,1,0,$time);
                    return true;
            }
    }
}