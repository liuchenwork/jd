<?php
    /**
     * 
     * @param type $data  任何数据类型进行打印，die
     */
    function P($data){
         echo '<pre>';
         $data = func_get_args($data);
         foreach ($data as $key => $value) {
             print_r($value);
             echo '<hr/>';         
         }
         exit;
    }
    
    function PP($data){
         echo '<pre>';
         $data = func_get_args($data);
         foreach ($data as $key => $value) {
             var_dump($value);
             echo '<hr/>';         
         }
         exit;
    }
    /**
     * 
     * @param type $data 任何数据类型进行文本打印
     */
    function FF($data){
        file_put_contents( './Application/Runtime/Temp/'.uniqid().'.txt', var_export($data , true));
    }
    /**
     *
     * @staticvar array $arr
     * @param type array $data    原始数组
     * @param type int $pid     上级id
     * @param type int $leaf    等级id,空格
     * @param type int $noid    除去本id和自己下面的所有的类
     * @return type array       返回按等级排序的二维数组
     */
    function get_tree($data , $pid , $leaf=0 ,$noid=0){
        // 保存静态数组
        static $arr = array();
        //循环原始数据，找出所给条件的值，放入一个一维数组中，形成一个二维数组
        foreach ($data as $value) {
             
            if($value['pid'] == $pid  && $value['id'] != $noid ){
                
                $value['leaf'] = $leaf;
                        
                $arr[] = $value;
                         
                //找出当代以下的子代
                get_tree( $data , $value['id'] ,$leaf+1 , $noid);
            }
        }
        
        return $arr;
    }
    
    
    
    
# for PHP < 5.5
# AND it works with arrayObject AND array of objects

    if (!function_exists('array_column')) {
	function array_column($array, $columnKey, $indexKey = null)
	{
		$result = array();
		foreach ($array as $subArray) {
			if (is_null($indexKey) && array_key_exists($columnKey, $subArray)) {
				$result[] = is_object($subArray)?$subArray->$columnKey: $subArray[$columnKey];
			} elseif (array_key_exists($indexKey, $subArray)) {
				if (is_null($columnKey)) {
					$index = is_object($subArray)?$subArray->$indexKey: $subArray[$indexKey];
					$result[$index] = $subArray;
				} elseif (array_key_exists($columnKey, $subArray)) {
					$index = is_object($subArray)?$subArray->$indexKey: $subArray[$indexKey];
					$result[$index] = is_object($subArray)?$subArray->$columnKey: $subArray[$columnKey];
				}
			}
		}
		return $result;
	}
}


    /**
     * 
     * @param type $exts   文件类型参数代表
     * @param type $size 文件的大小参数代表
     * @return type 如果上传成功输出，上传文件的路径
     */
    function upload($exts=1 ,$size=1 ){
        //获取上传文件的标签name属性值
        $key = key($_FILES);
        //判断是否上传文件
        if(!isset($_FILES[$key]['name']))
            return ;  
        //获取配置文件中设置的 上传问键的配置文件的数组
        $arr = C("UPLOAD");
        // 实例化上传类
        $upload = new \Think\Upload();
        // 设置附件上传类型 ， 配置文件
        $upload->exts = $arr['exts'][ $exts ];
        // 设置附件上传大小 ， 配置文件
        $upload->maxSize = $arr['size'][ $size ] ;
        // 公文管理设置的路径  通过html中post $_POST['_rootpath']=》/Public/Upload/Doc
        // 设置附件上传根目录
        $upload->rootPath = './'; 
         // 设置附件上传（子）目录  
        $upload->savePath = trim($_POST['_rootpath'] , '/' ) . '/';      
        // 上传文件,失败返回false
        $info = $upload->upload();           
        if($info)
            return  date('Y-m-d').'/'.$info[$key]['savename'];
    }
    
    
        
        
        /**
         * 数据写入文件
         * @param  string 参数1 文件名
         * @param  mix    任意参数
         * @param  num    最后一个参数,不填则顺序打印参数,填1则打印第二个数组参数
         * @author blovekite 20170113
         */
        function o()
        {
            $data = func_get_args();
           
            $filename=date('H-i-s',time());
            $file_name = './Datafile/' . $filename . '.text';

            $writedata = '';
            if(  count($data)===1 && is_array($data[0]) )
            {
                //用于可以查看变量名的[使用参数array('p1'=>$p1,'p2'=>$p2)]
                foreach ( $data[0] as $k => $v ) 
                {
                    $writedata .= $k . '=>' . PHP_EOL . var_export($v,true) . PHP_EOL . PHP_EOL;
                }
            }
            else
            {
                foreach ( $data as $k => $v)
                {
                    $writedata .= $k . '=>' . PHP_EOL . var_export($v,true) . PHP_EOL . PHP_EOL;
                }
            }
            file_put_contents( $file_name, $writedata);
        }
        
        
        function getTree( $parent ){
            foreach ( $parent as $son ) {
                    $parent[ $son['pid'] ][ 'children' ] [ $son['id'] ] = &$parent[ $son['id'] ];
            }
            // return $parent;
            return isset($parent[0]['children']) ? $parent[0]['children'] : false;
        }
                       
       //post方式的请求
        function postRequest($url,$data){
            //初始化curl函数
             $ch = curl_init();
             //设置请求的路径
             curl_setopt($ch, CURLOPT_URL,$url);
             //不验证ssl安全证书
             curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
             curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
             //设置请求的方式为post
             curl_setopt($ch,CURLOPT_POST,1);
             //传递post请求方式需要些带的数据
             curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
             //设置请求结果以文件流的形式返回而不是直接输出
             curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
             $output = curl_exec($ch);
              //关闭连接
              curl_close($ch);
             return $output;

        }
        //getf方式的请求
        function getRequest($url){
           // var_dump($url);die;
           $ch = curl_init();
           //设置请求的路径
           curl_setopt($ch,CURLOPT_URL,$url);
           //不需要验证ssl证书
           curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
           //设置获取的信息以文件流的形式返回,不在页面中输出任何结果
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
           $str = curl_exec($ch);
           curl_close($ch);

          return $str;
        }
        //将post请求方式与get请求方式进行综合
        function request($url,$https=false,$method="get",$data=null){
            //1 初始化curl函数
            $ch = curl_init($url);
            //2 设置相关的参数
            //以文件流的形式返回结果,不在页面输出任何结果
            curl_setopt($ch,CURLOPT_RETURNTRANSFER,0);
            //判断是否为https请求,如果是的话,就要验证ssl证书
            if($https==true){
                curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
                curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
            }
            //判断是否为post请求,如果是就传递参数
            if($method=='post'){
                curl_setopt($ch, CURLOPT_POST, TRUE);
                curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
            }
            //发送请求
            $str = curl_exec($ch);
          
            //关闭连接
            curl_close($ch);
             return  $str;
        }
        
        /**
  * 发送模板短信
  * @param to 手机号码集合,用英文逗号分开
  * @param datas 内容数据 格式为数组 例如：array('Marry','Alon')，如不需替换请填 null
  * @param $tempId 模板Id,测试应用和未上线应用使用测试模板请填写1，正式应用上线后填写已申请审核通过的模板ID
  */       
    function sendTemplateSMS($to,$datas,$tempId)
    {
        include_once("/Application/Api/Controller/CCPRestSmsSDK.php");
        //主帐号,对应开官网发者主账号下的 ACCOUNT SID
        $accountSid= '8aaf0708594f1f020159500506a800be';

        //主帐号令牌,对应官网开发者主账号下的 AUTH TOKEN
        $accountToken= 'd3fd7f8fcc41459385f3e7f9c49f696b';

        //应用Id，在官网应用列表中点击应用，对应应用详情中的APP ID
        //在开发调试的时候，可以使用官网自动为您分配的测试Demo的APP ID
        $appId='8a216da8594f29f801595d54bff40323';

        //请求地址
        //沙盒环境（用于应用开发调试）：sandboxapp.cloopen.com
        //生产环境（用户应用上线使用）：app.cloopen.com
        $serverIP='sandboxapp.cloopen.com';

        //请求端口，生产环境和沙盒环境一致
        $serverPort='8883';

        //REST版本号，在官网文档REST介绍中获得。
        $softVersion='2013-12-26'; 
        // 初始化REST SDK
         //global $accountSid,$accountToken,$appId,$serverIP,$serverPort,$softVersion;
         $rest = new \REST($serverIP,$serverPort,$softVersion);
         $rest->setAccount($accountSid,$accountToken);
         $rest->setAppId($appId);

         // 发送模板短信
         
         $result = $rest->sendTemplateSMS($to,$datas,$tempId);
         //发送返回无结果
         if($result == NULL ) {
             $data=array(
                 'sign'=>1,
                 'code'=>"result error!",
                 'msg' =>'调用失败!',
             );
             return $data;    
         }
         //发送返回结果是错误的
         if($result->statusCode!=0) {
              $data=array(
                 'sign'=>2,
                 'code'=>$result->statusCode,
                 'msg' =>$result->statusMsg,
             );
             return $data;            
             //TODO 添加错误处理逻辑
         }else{             
             // 获取返回信息，结果发送成功
             $smsmessage = $result->TemplateSMS;
             $data = array(
	         	'sign' => 0,
	         	'code' => 'send success' .$smsmessage->dateCreated .$smsmessage->smsMessageSid,
	         	'msg' => '短信发送成功！！！'
	         );
	     return $data;            
             //TODO 添加成功处理逻辑
         }
    }



