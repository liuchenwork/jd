<?php
return array(
	//'配置项'=>'配置值'    	
    'SHOW_PAGE_TRACE'       =>false,    //显示调试面板
    'SHOW_ERROR_MSG'        =>  false,    // 显示错误信息
    //
    //连接数据库
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  'localhost', // 服务器地址
    'DB_NAME'               =>  'tp_jd',          // 数据库名
    'DB_USER'               =>  'root',      // 用户名
    'DB_PWD'                =>  'root',          // 密码
    'DB_PORT'               =>  '3306',        // 端口
    'DB_PREFIX'             =>  'tp_',    // 数据库表前缀
        
    'URL_CASE_INSENSITIVE'  =>  true,   // 默认false 表示URL区分大小写 true则表示不区分大小写
    
    'DEFAULT_MODULE'        =>  'Admin',  // 默认模块
    'DEFAULT_CONTROLLER'    =>  'Public', // 默认控制器名称
    'DEFAULT_ACTION'        =>  'login', // 默认操作名称
    
    'URL_MODEL'             =>  1,       // URL访问模式,可选参数0、1、2、3,代表以下四种模式：
    // 0 (普通模式); 1 (PATHINFO 模式); 2 (REWRITE  模式); 3 (兼容模式)  默认为PATHINFO 模式
    
     'TMPL_PARSE_STRING' => array(
        '__ADMIN__'     => '/Public/Admin', // 更改默认的/Public 替换规则
        '__VENDOR__'    => '/Public/Vendor', // 增加新的JS类库路径替换规则
        '__HOME__'      => '/Public/Home',
        '__JQUERY__'    => '/Public/Vendor/jquery',
          //文件上传配置
         '__LOGO_UPLOADS__' => '/Public/Upload/Logo',  //公文管理 上传文件的路径
    ),
    
     //上传文件配置
    'UPLOAD' => array(
        //上传文件格式
        'exts' => array(
            1 => array( 'jpg', 'gif', 'png', 'jpeg' ),
            2 => array( 'zip' , 'rar' , 'doc' , 'ppt' ,'xls' , 'docx' , 'pptx' , 'xlsx' ,'txt' ),
            3 => array( 'avi' , 'rm' , 'rmvb' , 'mp4' ,'wmv'),
        ),
        //上传文件的大小
         'size' => array(
            1 => 1024*1024 ,
            2 => 1024*1024*2 ,
            3 => 1024*1024*3 ,
        ),
    ),
);