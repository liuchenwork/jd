<?php
namespace Home\Controller;
use Think\Controller;
class PublicController extends Controller {
    /**
     * 因为验证码在前后台都要用，在此把它放到前台
     */
    public function code(){
        $config = array(
            'fontSize' => 30, // 验证码字体大小
            'length' => 3, // 验证码位数
            'useNoise' => false, // 关闭验证码杂点
        );
        $Verify = new \Think\Verify($config);
        $Verify->entry();
    }
}